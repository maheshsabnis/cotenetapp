﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MyLiq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> Emps = new List<Employee>();

            Emps.Add(new Employee() { EmpNo = 1, EmpName = "Mahesh", Salary = 120000 });
            Emps.Add(new Employee() { EmpNo = 2, EmpName = "Ajay", Salary = 220000 });
            Emps.Add(new Employee() { EmpNo = 3, EmpName = "Mukesh", Salary = 110000 });
            Emps.Add(new Employee() { EmpNo = 4, EmpName = "Amar", Salary = 210000 });
            Emps.Add(new Employee() { EmpNo = 5, EmpName = "Tejas", Salary = 340000 });
            Emps.Add(new Employee() { EmpNo = 6, EmpName = "Kumar", Salary = 450000 });


            Console.WriteLine("List of All EMps");
            var allEmps = Emps.Select(e=>e);
            foreach (var item in allEmps)
            {
                Console.WriteLine($"{item.EmpNo} {item.EmpName} {item.Salary}");
            }

            Console.WriteLine("Ends Here");

            Console.WriteLine("List of All EMps");
            var Empsbysal = Emps.Where(e => e.Salary >= 300000);
            foreach (var item in Empsbysal)
            {
                Console.WriteLine($"{item.EmpNo} {item.EmpName} {item.Salary}");
            }
            Console.WriteLine("Ends Here");
            Console.WriteLine("List of All EMps Declarative");
            var bySal = from e in Emps
                        where e.Salary >= 300000
                        select e;

            foreach (var item in bySal)
            {
                Console.WriteLine($"{item.EmpNo} {item.EmpName} {item.Salary}");
            }
            Console.WriteLine("Ends Here");


            var res1 = Emps.Where(e => e.EmpName.StartsWith('M'))
                .OrderByDescending(e => e.EmpName)
                .Select(e => e);

            var res = from e in Emps
                      where e.EmpName.StartsWith('M')
                      orderby e.EmpName descending
                      select e;

            Console.ReadLine();
        }
    }
    public class Employee
    {
        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public int Salary { get; set; }
    }
}
