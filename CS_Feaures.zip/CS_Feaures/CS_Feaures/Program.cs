﻿using System;

namespace CS_Feaures
{
    class Program
    {
        public delegate int MyDele(int a, int b);

        static void Main(string[] args)
        {
            Console.WriteLine($"Diact call {Add(3,4)}");

            MyDele d = new MyDele(Add);
            Console.WriteLine($"Using Delegatr {d(5,6)}");

            Bridge(d);
             

            Bridge((x,y)=> { return x * y; });


            Console.ReadLine();
        }


        static void Bridge(MyDele d)
        {
            Console.WriteLine($"Result = {d(100,200)}");
        }

        static int Add(int x, int y)
        {
            return x + y;
        }
    }
}
